import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class EditTexto extends StatelessWidget {
  EditTexto(this.fieldIcontxt, this.hintTexttxt, this.controletxt);

  final Icon fieldIcontxt;
  final String hintTexttxt;
  final TextEditingController controletxt;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 250,
      child: Material(
          elevation: 5.0,
          borderRadius: BorderRadius.all(Radius.circular(10.0)),
          color: Colors.deepOrange,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: fieldIcontxt,
              ),
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(10.0),
                      bottomRight: Radius.circular(10.0)),
                ),
                width: 200,
                height: 60,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextField(
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: hintTexttxt,
                        fillColor: Colors.white,
                        filled: true),
                    style: TextStyle(
                        fontFamily: 'Quicksand',
                        fontSize: 20.0,
                        color: Colors.black),
                    controller: controletxt,
                    maxLength: 13,
                    keyboardType: TextInputType.text,
                  ),
                ),
              ),
            ],
          )),
    );
  }
}

class EditNumero extends StatelessWidget {
  EditNumero(this.fieldIconnr, this.hintTextnr, this.controlenr);

  final Icon fieldIconnr;
  final String hintTextnr;
  final TextEditingController controlenr;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 250,
      child: Material(
          elevation: 5.0,
          borderRadius: BorderRadius.all(Radius.circular(10.0)),
          color: Colors.deepOrange,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: fieldIconnr,
              ),
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(10.0),
                      bottomRight: Radius.circular(10.0)),
                ),
                width: 200,
                height: 60,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextField(
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: hintTextnr,
                        fillColor: Colors.white,
                        filled: true),
                    style: TextStyle(
                        fontFamily: 'Quicksand',
                        fontSize: 20.0,
                        color: Colors.black),
                    controller: controlenr,
                    keyboardType: TextInputType.number,
                  ),
                ),
              ),
            ],
          )),
    );
  }
}

class EditSenha extends StatelessWidget {
  EditSenha(this.hintTextpwd, this.controlepwd);
  final String hintTextpwd;
  final TextEditingController controlepwd;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 250,
      child: Material(
          elevation: 5.0,
          borderRadius: BorderRadius.all(Radius.circular(10.0)),
          color: Colors.deepOrange,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Icon(Icons.lock, color: Colors.white),
              ),
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(10.0),
                      bottomRight: Radius.circular(10.0)),
                ),
                width: 200,
                height: 60,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextField(
                    obscureText: true,
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: hintTextpwd,
                        fillColor: Colors.white,
                        filled: true),
                    style: TextStyle(
                        fontFamily: 'Quicksand',
                        fontSize: 20.0,
                        color: Colors.black),
                    controller: controlepwd,
                    keyboardType: TextInputType.text,
                  ),
                ),
              ),
            ],
          )),
    );
  }
}

class BotoesMenu extends StatelessWidget {
  BotoesMenu(this.txtbtn, this.icone, this.pagina);

  final String txtbtn;
  final IconData icone;
  final String pagina;

  @override
  Widget build(BuildContext context) {
    return Container(
      //padding: const EdgeInsets.all(10),
      width: MediaQuery.of(context).size.width - 40,
      margin: const EdgeInsets.all(1.00),
      //padding: const EdgeInsets.only(left: 30.0, right: 30.0),
      child: new Row(
        children: <Widget>[
          new Expanded(
            child: FlatButton(
              shape: new RoundedRectangleBorder(
                  borderRadius: new BorderRadius.circular(30.0)),
              splashColor: Colors.deepPurple,
              color: Colors.deepOrange,
              child: new Row(
                children: <Widget>[
                  new Padding(
                    padding: const EdgeInsets.only(left: 20.0),
                    child: Text(
                      txtbtn,
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontFamily: 'Quicksand',
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                  new Expanded(
                    child: Container(),
                  ),
                  new Transform.translate(
                    offset: Offset(15.0, 0.0),
                    child: new Container(
                      padding: const EdgeInsets.all(5.0),
                      child: FlatButton(
                        shape: new RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(28.0)),
                        splashColor: Colors.blueGrey,
                        color: Colors.white,
                        child: Icon(
                          icone,
                          color: Colors.deepOrange,
                          size: 30,
                        ),
                        onPressed: () => Navigator.pushNamed(context, pagina),
                      ),
                    ),
                  )
                ],
              ),
              onPressed: () => Navigator.pushNamed(context, pagina),
            ),
          ),
        ],
      ),
    );
  }
}

class EditNumeroOnly extends StatelessWidget {
  EditNumeroOnly(this.fieldIconnr, this.hintTextnr, this.controlenr);
  final Icon fieldIconnr;
  final String hintTextnr;
  final TextEditingController controlenr;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 250,
      child: Material(
          elevation: 5.0,
          borderRadius: BorderRadius.all(Radius.circular(10.0)),
          color: Colors.deepOrange,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: fieldIconnr,
              ),
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(10.0),
                      bottomRight: Radius.circular(10.0)),
                ),
                width: 200,
                height: 60,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextField(
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: hintTextnr,
                        fillColor: Colors.white,
                        filled: true),
                    style: TextStyle(
                        fontFamily: 'Quicksand',
                        fontSize: 20.0,
                        color: Colors.black),
                    controller: controlenr,
                    maxLength: 13,
                    inputFormatters: [
                      WhitelistingTextInputFormatter.digitsOnly
                    ],
                    keyboardType: TextInputType.number,
                  ),
                ),
              ),
            ],
          )),
    );
  }
}

class CardProduto extends StatelessWidget {
  CardProduto(this.nomeprod, this.idprod, this.ean, this.estoque);
  final String nomeprod;
  final String idprod;
  final String ean;
  final String estoque;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: new SingleChildScrollView(
        child: Container(
          alignment: Alignment.centerLeft,
          margin: new EdgeInsets.all(8.0),
          padding: new EdgeInsets.all(8.0),
          height: 170.0,
          decoration: new BoxDecoration(
            color: Colors.deepOrange,
            borderRadius: new BorderRadius.all(new Radius.circular(10.0)),
            boxShadow: [
              new BoxShadow(
                  color: Colors.black54,
                  offset: new Offset(2.0, 2.0),
                  blurRadius: 5.0)
            ],
            image: new DecorationImage(
              image: new AssetImage("images/background.png"),
              fit: BoxFit.cover,
            ),
          ),
          child: new Row(
            children: <Widget>[
              new Expanded(
                  child: new Padding(
                padding: new EdgeInsets.only(left: 8.0),
                child: new Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    new Text(
                      nomeprod,
                      style: new TextStyle(
                          fontFamily: 'Quicksand',
                          fontSize: 16.0,
                          fontWeight: FontWeight.bold),
                    ),
                    new Wrap(spacing: 5.0),
                    new Text(
                      idprod,
                      style: new TextStyle(
                          fontFamily: 'Quicksand',
                          fontSize: 16.0,
                          fontWeight: FontWeight.bold),
                    ),
                    new Wrap(spacing: 5.0),
                    new Text(
                      ean,
                      style: new TextStyle(
                          fontFamily: 'Quicksand',
                          fontSize: 16.0,
                          fontWeight: FontWeight.bold),
                    ),
                    new Text(
                      estoque,
                      style: new TextStyle(
                        fontFamily: 'Quicksand',
                        fontSize: 20.0,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    new Row(
                        //MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          new FlatButton(
                            shape: new RoundedRectangleBorder(
                                borderRadius: new BorderRadius.circular(30.0)),
                            splashColor: Colors.deepPurple,
                            color: Colors.deepOrange[300],
                            child: new Row(
                              children: <Widget>[
                                new Padding(
                                  padding: const EdgeInsets.all(5),
                                  child: Text(
                                    "Alterar o estoque",
                                    style: TextStyle(
                                        fontFamily: 'Quicksand',
                                        color: Colors.white),
                                  ),
                                ),
                              ],
                            ),
                            onPressed: () => {},
                          ),
                          new FlatButton(
                            shape: new RoundedRectangleBorder(
                                borderRadius: new BorderRadius.circular(30.0)),
                            splashColor: Colors.deepPurple,
                            color: Colors.deepOrange[300],
                            child: new Row(
                              children: <Widget>[
                                new Padding(
                                  padding: const EdgeInsets.all(5),
                                  child: Text(
                                    "Alterar EAN",
                                    style: TextStyle(
                                        fontFamily: 'Quicksand',
                                        color: Colors.white),
                                  ),
                                ),
                              ],
                            ),
                            onPressed: () => {},
                          ),
                        ]),
                  ],
                ),
              ))
            ],
          ),
        ),
      ),
    );
  }
}
