import 'UI/CustomInputField.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class WidgetMenu extends StatelessWidget {

 final String ip;
  WidgetMenu({Key key, @required this.ip}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: new SingleChildScrollView(
        child: Container(
          decoration: new BoxDecoration(
            image: new DecorationImage(
              image: AssetImage('assets/background.png'),
              fit: BoxFit.cover,
            ),
          ),

          width: MediaQuery.of(context).size.width,
          //width: 250,
          height: MediaQuery.of(context).size.height,
          //color: Colors.white,
          child: Stack(
            children: <Widget>[
              Center(
                child: Container(
                  //width: 500,
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      Material(
                          elevation: 10.0,
                          borderRadius:
                              BorderRadius.all(Radius.circular(100.0)),
                          child: Padding(
                            padding: const EdgeInsets.all(30.0),
                            child: Text(
                              'Menu Principal',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 25,
                                  color: Colors.deepOrange),
                            ),
                          )),
                      BotoesMenu('CATEGORIAS', Icons.category, '/categorias'),
                      BotoesMenu('CÓDIGO INTERNO', Icons.code, '/codproduto'),
                      BotoesMenu('CÓDIGO DE BARRAS', Icons.settings_ethernet, '/codEAN'),
                      BotoesMenu('DESCRIÇÃO', Icons.comment, '/descricao'),
                      BotoesMenu('REFERÊNCIA', Icons.swap_horiz, '/referencia'),
                      BotoesMenu('SEM CÓDIGO', Icons.data_usage, '/semEAN'),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
