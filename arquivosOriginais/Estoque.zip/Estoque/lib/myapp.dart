import 'package:Estoque/WidgetCategorias.dart';
import 'package:Estoque/WidgetDescricao.dart';
import 'package:Estoque/widgetCodProduto.dart';
import 'package:Estoque/widgetEan.dart';
import 'package:Estoque/widgetReferencia.dart';
import 'package:Estoque/widgetSemEan.dart';
import 'package:flutter/material.dart';
import 'package:Estoque/homescreen.dart';

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: HomeScreen(),
        routes: <String, WidgetBuilder>{
          '/categorias': (BuildContext context) => new WidgetCategorias(),
          '/codproduto': (BuildContext context) => new WIdGetCodProduto(),
          '/codEAN': (BuildContext context) => new WidgetEan(),
          '/referencia': (BuildContext context) => new WidgetReferencia(),
          '/descricao': (BuildContext context) => new WidgetDescricao(),
          '/semEAN': (BuildContext context) => new WidgetSemEan(),
        }
        );
  }
}