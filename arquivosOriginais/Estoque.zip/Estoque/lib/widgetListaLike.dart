import 'package:Estoque/dm/consultas.dart';
import 'package:Estoque/widgetAlteraSelecionado.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class WidgetListaLike extends StatelessWidget {
  final String text;
  WidgetListaLike({Key key, @required this.text})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: new AppBar(
        backgroundColor: Colors.deepOrange,
        title: new Center(
            child: new Text(
          'Resultado da pesquisa',
          textAlign: TextAlign.center,
          style: TextStyle(fontWeight: FontWeight.bold),
        )),
      ),
      body: Stack(
        children: <Widget>[
          Container(
            decoration: new BoxDecoration(
              image: new DecorationImage(
                image: AssetImage('assets/background.png'),
                fit: BoxFit.cover,
              ),
            ),
            child: Center(
              child: FutureBuilder<List<Produtos>>(
                future: fetchListProdutos('ProdLike',text),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    List<Produtos> categoria = snapshot.data;

                    return ListView(
                      padding: EdgeInsets.all(15.0),
                      children: categoria
                          .map((categoria) => Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: <Widget>[
                                  GestureDetector(
                                    onTap: () {
                                      Navigator.push(
                                          context,
                                          CupertinoPageRoute(
                                            builder: (context) =>
                                                WidgetAlteraSelecionado(
                                                  nome: '${categoria.nome}',
                                                  unidade:
                                                      '${categoria.unidade}',
                                                  codigo:
                                                      '${categoria.codproduto}',
                                                  ean: '${categoria.ean}',
                                                  estoque:
                                                      '${categoria.estoque}',
                                                  valor:
                                                      '${categoria.valor}',
                                                ),
                                          ));
                                    },
                                    child: Container(
                                      alignment: Alignment.centerLeft,
                                      margin: new EdgeInsets.all(8.0),
                                      padding: new EdgeInsets.all(8.0),
                                      height: 170.0,
                                      decoration: BoxDecoration(
                                        color: Colors.deepOrange,
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(10.0)),
                                        boxShadow: [
                                          new BoxShadow(
                                              color: Colors.black54,
                                              offset: new Offset(2.0, 2.0),
                                              blurRadius: 5.0)
                                        ],
                                        image: DecorationImage(
                                          image: AssetImage(
                                              'assets/background2.png'),
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      child: Row(
                                        children: <Widget>[
                                          Expanded(
                                              child: new Padding(
                                            padding:
                                                new EdgeInsets.only(left: 8.0),
                                            child: new Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: <Widget>[
                                                Text(
                                                  '${categoria.nome}',
                                                  style: new TextStyle(
                                                      fontSize: 16.0,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                                Wrap(spacing: 5.0),
                                                Row(
                                                  children: [
                                                    Expanded(
                                                      /*1*/
                                                      child: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          /*2*/
                                                          Text(
                                                            'CÓDIGO: ' +
                                                                '${categoria.codproduto}',
                                                            style: new TextStyle(
                                                                fontFamily:
                                                                    'Quicksand',
                                                                fontSize: 16.0,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold),
                                                          ),
                                                          Text(
                                                            'EAN: ' +
                                                                '${categoria.ean}',
                                                            style: new TextStyle(
                                                                fontFamily:
                                                                    'Quicksand',
                                                                fontSize: 16.0,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    /*3*/
                                                    Chip(
                                                      backgroundColor: Colors.white,
                                                      avatar: CircleAvatar(
                                                        backgroundColor: Colors.blueGrey[100],
                                                        child: Text('R\$',
                                                        style: TextStyle(
                                                          color: Colors.black,
                                                            fontFamily:
                                                                'Quicksand',
                                                            //fontSize: 20.0,
                                                            fontWeight:
                                                                FontWeight
                                                                    .bold
                                                        ),),
                                                      ),
                                                      label: Text(
                                                        '${categoria.valor}',
                                                        style: TextStyle(
                                                            fontFamily:
                                                                'Quicksand',
                                                            fontSize: 20.0,
                                                            fontWeight:
                                                                FontWeight
                                                                    .bold
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                Text(
                                                  '',
                                                  style: new TextStyle(
                                                      fontSize: 16.0,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                                Container(
                                                  alignment: Alignment.center,
                                                  width: MediaQuery.of(context)
                                                          .size
                                                          .width -
                                                      20,
                                                  height: 40,
                                                  child: Align(
                                                    alignment: Alignment.center,
                                                    child: Container(
                                                      width:
                                                          MediaQuery.of(context)
                                                                  .size
                                                                  .width -
                                                              20,
                                                      height: 40,
                                                      decoration: BoxDecoration(
                                                        color:
                                                            Colors.deepOrange,
                                                        borderRadius:
                                                            BorderRadius.all(
                                                                Radius.circular(
                                                                    10.0)),
                                                        boxShadow: [
                                                          new BoxShadow(
                                                              color: Colors
                                                                  .black54,
                                                              offset:
                                                                  new Offset(
                                                                      2.0, 2.0),
                                                              blurRadius: 5.0)
                                                        ],
                                                        image: DecorationImage(
                                                          image: AssetImage(
                                                              'assets/background.png'),
                                                          fit: BoxFit.cover,
                                                        ),
                                                      ),
                                                      child: Row(
                                                          children: <Widget>[
                                                            Text(
                                                              '   ESTOQUE ATUAL: ' +
                                                                  '${categoria.estoque}' +
                                                                  ' ' +
                                                                  '${categoria.unidade}',
                                                              style:
                                                                  new TextStyle(
                                                                fontSize: 20.0,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                              ),
                                                            ),
                                                          ]),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ))
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ))
                          .toList(),
                    );
                  } else if (snapshot.hasError) {
                    return Text('Servidor desligado ou IP errado');
                  }
                  return new CircularProgressIndicator();
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
