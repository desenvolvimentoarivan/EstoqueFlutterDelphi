import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

alerta(String txt) {
  Fluttertoast.showToast(
      msg: txt,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.TOP,
      timeInSecForIos: 1,
      backgroundColor: Colors.deepOrange,
      textColor: Colors.white,
      fontSize: 16.0);
}

//metodo para ler a lista de categorias no rest
Future<List<Categorias>> fetchListCategoria() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  String ip = prefs.getString("ipserver");
  final response =
      await http.get('http://' + ip + ':8082/eventos/GetCategoria?');

  if (response.statusCode == 200) {
    List categoria = json.decode(utf8.decode(response.bodyBytes));

    return categoria
        .map((categoria) => new Categorias.fromJson(categoria))
        .toList();
  } else
    throw Exception('Erro ao carregar categorias');
}

class Categorias {
  final String codcategoria, nome;

  Categorias({this.codcategoria, this.nome});

  factory Categorias.fromJson(Map<String, dynamic> json) {
    return Categorias(codcategoria: json['CODCATEGORIA'], nome: json['NOME']);
  }
}

//produtos generico
Future<List<Produtos>> fetchListProdutos(String url, codigo) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  String ip = prefs.getString("ipserver");
  String _url = 'http://$ip:8082/eventos/$url?pSelect=$codigo';
  final response = await http.get(_url);
  if (response.statusCode == 200) {
    List produtos = json.decode(utf8.decode(response.bodyBytes));
    return produtos.map((produtos) => new Produtos.fromJson(produtos)).toList();
  } else
    throw Exception('Erro ao carregar produtos');
}

class Produtos {
  final String codproduto, nome, unidade, ean, estoque, valor;

  Produtos(
      {this.codproduto,
      this.nome,
      this.unidade,
      this.ean,
      this.estoque,
      this.valor});

  factory Produtos.fromJson(Map<String, dynamic> json) {
    return Produtos(
        codproduto: json['CODPRODUTO'],
        nome: json['NOME'],
        unidade: json['UNIDADE'],
        ean: json['CODBARRA'],
        estoque: json['ESTOQUE'],
        valor: json['VALOR']);
  }
}

void gravaEan(String codbar, codigo, oldEan) async {
  if (codbar != oldEan) {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    String ipservidor = prefs.getString("ipserver");
    String url = 'http://' +
        ipservidor +
        ':8082/eventos/Gravar?pSelect=' +
        'update produto set codbarra = ' +
        "'" +
        codbar +
        "'" +
        ' where codproduto =' +
        "'" +
        codigo +
        "'";
    await http.post(url);
  }
}

void gravaEstoque(String vlrEstoque, codigo, oldEstoque) async {
  if (vlrEstoque != oldEstoque) {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    String ipservidor = prefs.getString("ipserver");
    String url = 'http://' +
        ipservidor +
        ':8082/eventos/Gravar?pSelect=' +
        'update estoque set estoque = ' +
        vlrEstoque +
        ' where codproduto =' +
        "'" +
        codigo +
        "'";
    await http.post(url);
  }
}

void gravaPreco(String vlrEstoque, codigo, oldValor) async {
  if (vlrEstoque != oldValor) {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    String ipservidor = prefs.getString("ipserver");
    String url = 'http://' +
        ipservidor +
        ':8082/eventos/Gravar?pSelect=' +
        'update produto set precov1 = ' +
        vlrEstoque +
        ' where codproduto =' +
        "'" +
        codigo +
        "'";
    await http.post(url);
  }
}
