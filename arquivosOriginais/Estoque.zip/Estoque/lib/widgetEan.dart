import 'package:Estoque/dm/consultas.dart';
import 'package:Estoque/widgetListaEan.dart';
import 'package:http/http.dart' as http;
import 'UI/CustomInputField.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:simple_permissions/simple_permissions.dart';
import 'package:flutter/services.dart';
import 'package:qrscan/qrscan.dart' as scanner;

class WidgetEan extends StatefulWidget {
  @override
  _WidgetEanState createState() => _WidgetEanState();
}

class _WidgetEanState extends State<WidgetEan> {
  TextEditingController codProduto = TextEditingController();
  SharedPreferences sharedPreferences;
  String ip, fracionado, refere;
  Permission permission = Permission.Camera;

  @override
  void initState() {
    super.initState();
    _getIP();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: new GestureDetector(
        onTap: () {
          // call this method here to hide soft keyboard
          FocusScope.of(context).requestFocus(new FocusNode());
        },
        child: SingleChildScrollView(
          child: Container(
            decoration: new BoxDecoration(
              image: new DecorationImage(
                image: AssetImage('assets/background.png'),
                fit: BoxFit.cover,
              ),
            ),
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: Stack(
              children: <Widget>[
                Center(
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    height: 500,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        Material(
                            elevation: 5.0,
                            borderRadius:
                                BorderRadius.all(Radius.circular(100.0)),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                'Digite o código de barras',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 25,
                                    color: Colors.deepOrange),
                              ),
                            )),
                        EditNumeroOnly(Icon(Icons.code, color: Colors.white),
                            'Mín. de 4 dígitos', codProduto),
                        Container(
                          width: 250,
                          margin: const EdgeInsets.only(top: 10.0),
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: FlatButton(
                                  shape: new RoundedRectangleBorder(
                                      borderRadius:
                                          new BorderRadius.circular(30.0)),
                                  splashColor: Colors.deepPurple,
                                  color: Colors.deepOrange,
                                  child: new Row(
                                    children: <Widget>[
                                      new Padding(
                                        padding:
                                            const EdgeInsets.only(left: 20.0),
                                        child: Text(
                                          "Pesquisar",
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      ),
                                      new Expanded(
                                        child: Container(),
                                      ),
                                      new Transform.translate(
                                        offset: Offset(15.0, 0.0),
                                        child: new Container(
                                          padding: const EdgeInsets.all(5.0),
                                          child: FlatButton(
                                            shape: new RoundedRectangleBorder(
                                                borderRadius:
                                                    new BorderRadius.circular(
                                                        28.0)),
                                            splashColor: Colors.blueGrey,
                                            color: Colors.white,
                                            child: Icon(Icons.search),
                                            onPressed: () {
                                              _clicaPesquisa();
                                            },
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                  onPressed: () {
                                    fracionado = null;
                                    refere = null;
                                    _clicaPesquisa();
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: 250,
                          margin: const EdgeInsets.only(top: 10.0),
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: FlatButton(
                                  shape: new RoundedRectangleBorder(
                                      borderRadius:
                                          new BorderRadius.circular(30.0)),
                                  splashColor: Colors.deepPurple,
                                  color: Colors.deepOrange,
                                  child: new Row(
                                    children: <Widget>[
                                      new Padding(
                                        padding:
                                            const EdgeInsets.only(left: 20.0),
                                        child: Text(
                                          "Escanear",
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      ),
                                      new Expanded(
                                        child: Container(),
                                      ),
                                      new Transform.translate(
                                        offset: Offset(15.0, 0.0),
                                        child: new Container(
                                          padding: const EdgeInsets.all(5.0),
                                          child: FlatButton(
                                            shape: new RoundedRectangleBorder(
                                                borderRadius:
                                                    new BorderRadius.circular(
                                                        28.0)),
                                            splashColor: Colors.blueGrey,
                                            color: Colors.white,
                                            child: Icon(Icons.camera_alt),
                                            onPressed: () {
                                              scan();
                                            },
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                  onPressed: () {
                                    scan();
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  _getIP() async {
    sharedPreferences = await SharedPreferences.getInstance();
    ip = sharedPreferences.getString("ipserver");
  }

  _clicaPesquisa() {
    if (codProduto.text.length >= 4) {
      fetchListProd();
    } else {
      alerta("Digite no mínimo 4 dígitos");
    }
  }

  //Future<List<ProdLike>> fetchListProd() async {
  fetchListProd() async {
    if (fracionado == '2') {
      final response = await http
          .get('http://' + ip + ':8082/eventos/ProdEan?' + 'pSelect=' + refere);
      if (response.statusCode == 200) {
        if (response.body != '{"PRODUTOS": "VAZIO"}') {
          Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => WidgetListaEan(
                      text: refere,
                      ipservidor: ip,
                      refere: refere,
                    ),
              ));
        } else {
          alerta('Nenhum produto encontrado');
        }
      } else {
        alerta("Sem conexão com o servidor");
      }
    } else {
      if (refere != null) {
        final response = await http.get(
            'http://' + ip + ':8082/eventos/EanFrac?' + 'pSelect=' + refere);
        if (response.statusCode == 200) {
          if (response.body != '{"PRODUTOS": "VAZIO"}') {
            Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => WidgetListaEan(
                        text: refere,
                        ipservidor: ip,
                        refere: refere,
                      ),
                ));
          } else {
            alerta('Nenhum produto encontrado');
          }
        } else {
          alerta('Erro na requisição');
        }
      } else {
        final response = await http.get('http://' +
            ip +
            ':8082/eventos/ProdEan?' +
            'pSelect=' +
            codProduto.text);
        if (response.statusCode == 200) {
          if (response.body != '{"PRODUTOS": "VAZIO"}') {
            Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => WidgetListaEan(
                        text: codProduto.text,
                        ipservidor: ip,
                        refere: '',
                      ),
                ));
          } else {
            alerta('Nenhum produto encontrado');
          }
        } else {
          alerta('Erro na requisição');
        }
      }
    }
  }

  requestPermission() async {
    final result = await SimplePermissions.requestPermission(permission);
    setState(
      () => new SnackBar(
            backgroundColor: Colors.red,
            content: new Text(" $result"),
          ),
    );
  }

  scan() async {
    fracionado = '';
    codProduto.clear();
    try {
      String reader = await scanner.scan();

      if (!mounted) {
        return;
      }

      setState(() {
        codProduto.text = reader;
        fracionado = reader;
        fracionado = fracionado.substring(0, 1);

        refere = reader;
        refere = refere.substring(1, 5);
        
        if (fracionado != '2') {
          fracionado = null;
          refere = null;
        }
        _clicaPesquisa();
      });
    } on PlatformException catch (e) {
      if (e.code == scanner.CameraAccessDenied) {
        requestPermission();
      }
    }
  }
}
