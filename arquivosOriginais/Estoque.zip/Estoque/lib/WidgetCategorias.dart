import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:Estoque/widgetalteraestoque.dart';
import 'package:Estoque/dm/consultas.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

class WidgetCategorias extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    
    ifTemProdutos(String codigo, nome) async {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String ip = prefs.getString("ipserver");
      String _url = 'http://$ip:8082/eventos/ProdCat?pSelect=$codigo';

      final response = await http.get(_url);
      
      if (response.statusCode == 200) {
        if (response.body != '{"PRODUTOS": "VAZIO"}') {
          Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => WidgetAlteraEstoque(
                      text: codigo,
                      nomecat: nome,
                    ),
              ));
        } else {
          alerta('Categoria sem produtos');
        }
      } else {
        alerta('Erro na requisição');
      }
    }

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: new AppBar(
          backgroundColor: Colors.deepOrange,
          title: new Center(
              child: new Text(
            'Lista de categorias',
            textAlign: TextAlign.center,
            style:
                TextStyle(fontFamily: 'Quicksand', fontWeight: FontWeight.bold),
          )),
        ),
        body: Stack(
          children: <Widget>[
            Container(
              decoration: new BoxDecoration(
                image: new DecorationImage(
                  image: AssetImage('assets/background.png'),
                  fit: BoxFit.cover,
                ),
              ),
              child: Center(
                //child: Container(),

                child: FutureBuilder<List<Categorias>>(
                  future: fetchListCategoria(),
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      List<Categorias> categoria = snapshot.data;

                      return ListView(
                        padding: EdgeInsets.all(15.0),
                        children: categoria
                            .map((categoria) => Column(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                  children: <Widget>[
                                    FlatButton(
                                        shape: new RoundedRectangleBorder(
                                            borderRadius:
                                                new BorderRadius.circular(
                                                    30.0)),
                                        splashColor: Colors.deepPurple,
                                        color: Colors.deepOrange,
                                        child: Row(
                                          children: <Widget>[
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 20.0),
                                              child: Text(
                                                '${categoria.nome}',
                                                style: TextStyle(
                                                    fontFamily: 'Quicksand',
                                                    color: Colors.white,
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                            ),
                                            Expanded(
                                              child: Container(),
                                            ),
                                          ],
                                        ),
                                        onPressed: () {
                                          ifTemProdutos('${categoria.codcategoria}',
                                              '${categoria.nome}');
                                        })
                                  ],
                                ))
                            .toList(),
                      );
                    } else if (snapshot.hasError) {
                      return Text('Servidor desligado ou IP errado');
                    }
                    return new CircularProgressIndicator();
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
