import 'package:Estoque/dm/consultas.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:simple_permissions/simple_permissions.dart';
import 'package:flutter/services.dart';
import 'package:qrscan/qrscan.dart' as scanner;

class WidgetAlteraSelecionado extends StatefulWidget {
  final String nome, unidade, codigo, ean, estoque, valor;

  const WidgetAlteraSelecionado(
      {Key key,
      this.nome,
      this.unidade,
      this.codigo,
      this.ean,
      this.estoque,
      this.valor})
      : super(key: key);

  @override
  _WidgetAlteraSelecionadoState createState() =>
      _WidgetAlteraSelecionadoState();
}

class _WidgetAlteraSelecionadoState extends State<WidgetAlteraSelecionado> {
  SharedPreferences sharedPreferences;

  TextEditingController ctrlEstoque = TextEditingController();
  TextEditingController ctrlEan = TextEditingController();
  TextEditingController ctrlVenda = TextEditingController();

  String ipserver = '';
  String oldEan = '';
  String oldEstoque = '';
  String oldValor = '';

  Permission permission = Permission.Camera;

  FocusNode myFocusNode;

  @override
  void initState() {
    super.initState();
    getControllers();
    myFocusNode = FocusNode();
  }

  @override
  void dispose() {
    // Clean up the focus node when the Form is disposed
    myFocusNode.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepOrange,
        title: Center(
            child: Text(
          'Alterar produto',
          textAlign: TextAlign.center,
          style: TextStyle(fontWeight: FontWeight.bold),
        )),
      ),
      body: Stack(children: <Widget>[
        Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/background.png'),
              fit: BoxFit.cover,
            ),
          ),
          child: SingleChildScrollView(
            padding: EdgeInsets.only(top: 25, bottom: 25),
            child: Container(
              alignment: Alignment.center,
              margin: EdgeInsets.all(8.0),
              padding: EdgeInsets.all(8.0),
              height: MediaQuery.of(context).size.height - 150,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                color: Colors.deepOrange,
                borderRadius: BorderRadius.all(Radius.circular(10.0)),
                boxShadow: [
                  BoxShadow(
                      color: Colors.black54,
                      offset: new Offset(2.0, 2.0),
                      blurRadius: 5.0)
                ],
                image: DecorationImage(
                  image: AssetImage('assets/background2.png'),
                  fit: BoxFit.cover,
                ),
              ),
              child: Row(
                children: <Widget>[
                  Expanded(
                      child: Padding(
                    padding: EdgeInsets.only(left: 8.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          widget.nome,
                          style: TextStyle(
                              fontFamily: 'Quicksand',
                              fontSize: 16.0,
                              fontWeight: FontWeight.bold),
                        ),
                        Wrap(spacing: 5.0),
                        Row(
                          children: [
                            Expanded(
                              /*1*/
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  /*2*/
                                  Text(
                                    'CÓDIGO: ' + widget.codigo,
                                    style: new TextStyle(
                                        fontFamily: 'Quicksand',
                                        fontSize: 16.0,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  Text(
                                    'EAN: ' + widget.ean,
                                    style: new TextStyle(
                                        fontFamily: 'Quicksand',
                                        fontSize: 16.0,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ],
                              ),
                            ),
                            /*3*/
                            Chip(
                              backgroundColor: Colors.white,
                              avatar: CircleAvatar(
                                backgroundColor: Colors.blueGrey[100],
                                child: Text(
                                  'R\$',
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontFamily: 'Quicksand',
                                      //fontSize: 20.0,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              label: Text(
                                widget.valor,
                                style: TextStyle(
                                    fontFamily: 'Quicksand',
                                    fontSize: 20.0,
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                          ],
                        ),
                        Text(
                          'ESTOQUE ATUAL: ' +
                              widget.estoque +
                              ' ' +
                              widget.unidade,
                          style: TextStyle(
                            fontFamily: 'Quicksand',
                            fontSize: 20.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Wrap(spacing: 50.0),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            new Text(
                              '',
                              style: new TextStyle(
                                  fontSize: 16.0, fontWeight: FontWeight.bold),
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width,
                              child: Material(
                                  elevation: 5.0,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(10.0)),
                                  color: Colors.deepOrange,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Text(
                                          'Estoque:',
                                          style: new TextStyle(
                                              fontFamily: 'Quicksand',
                                              fontSize: 20.0,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                      Container(
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.only(
                                              topRight: Radius.circular(10.0),
                                              bottomRight:
                                                  Radius.circular(10.0)),
                                        ),
                                        width: 200,
                                        height: 60,
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: TextField(
                                            focusNode: myFocusNode,
                                            decoration: InputDecoration(
                                                border: InputBorder.none,
                                                hintText: 'Estoque...',
                                                fillColor: Colors.white,
                                                filled: true),
                                            style: TextStyle(
                                                fontFamily: 'Quicksand',
                                                fontSize: 20.0,
                                                color: Colors.black),
                                            controller: ctrlEstoque,
                                            keyboardType: TextInputType.number,
                                          ),
                                        ),
                                      ),
                                    ],
                                  )),
                            ),
                            new Text(
                              '',
                              style: new TextStyle(
                                  fontSize: 16.0, fontWeight: FontWeight.bold),
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width,
                              child: Material(
                                  elevation: 5.0,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(10.0)),
                                  color: Colors.deepOrange,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Text(
                                          'Barras:',
                                          style: new TextStyle(
                                              fontFamily: 'Quicksand',
                                              fontSize: 20.0,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                      Container(
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.only(
                                              topRight: Radius.circular(10.0),
                                              bottomRight:
                                                  Radius.circular(10.0)),
                                        ),
                                        width: 200,
                                        height: 60,
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: TextField(
                                            decoration: InputDecoration(
                                                border: InputBorder.none,
                                                hintText: 'Barras...',
                                                fillColor: Colors.white,
                                                filled: true),
                                            style: TextStyle(
                                                fontFamily: 'Quicksand',
                                                fontSize: 20.0,
                                                color: Colors.black),
                                            controller: ctrlEan,
                                            //initialValue: ctrlEan.text,
                                            keyboardType: TextInputType.number,
                                          ),
                                        ),
                                      ),
                                    ],
                                  )),
                            ),
                            new Text(
                              '',
                              style: new TextStyle(
                                  fontSize: 16.0, fontWeight: FontWeight.bold),
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width,
                              child: Material(
                                  elevation: 5.0,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(10.0)),
                                  color: Colors.deepOrange,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Text(
                                          'R\$ Venda:',
                                          style: new TextStyle(
                                              fontFamily: 'Quicksand',
                                              fontSize: 20.0,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                      Container(
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.only(
                                              topRight: Radius.circular(10.0),
                                              bottomRight:
                                                  Radius.circular(10.0)),
                                        ),
                                        width: 200,
                                        height: 60,
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: TextField(
                                            decoration: InputDecoration(
                                                border: InputBorder.none,
                                                hintText: 'R\$ Venda...',
                                                fillColor: Colors.white,
                                                filled: true),
                                            style: TextStyle(
                                                fontFamily: 'Quicksand',
                                                fontSize: 20.0,
                                                color: Colors.black),
                                            controller: ctrlVenda,
                                            keyboardType: TextInputType.number,
                                          ),
                                        ),
                                      ),
                                    ],
                                  )),
                            ),
                            new Text(
                              '',
                              style: new TextStyle(
                                  fontSize: 16.0, fontWeight: FontWeight.bold),
                            ),
                            FlatButton(
                              shape: new RoundedRectangleBorder(
                                  borderRadius:
                                      new BorderRadius.circular(30.0)),
                              splashColor: Colors.deepPurple,
                              color: Colors.deepOrange,
                              child: new Row(
                                children: <Widget>[
                                  new Padding(
                                    padding: const EdgeInsets.only(left: 20.0),
                                    child: Text(
                                      "SALVAR ALTERAÇÕES",
                                      style: TextStyle(
                                          fontFamily: 'Quicksand',
                                          color: Colors.white),
                                    ),
                                  ),
                                  new Expanded(
                                    child: Container(),
                                  ),
                                  new Transform.translate(
                                    offset: Offset(15.0, 0.0),
                                    child: new Container(
                                      padding: const EdgeInsets.all(5.0),
                                      child: FlatButton(
                                          shape: new RoundedRectangleBorder(
                                              borderRadius:
                                                  new BorderRadius.circular(
                                                      28.0)),
                                          splashColor: Colors.blueGrey,
                                          color: Colors.white,
                                          child: Text('Voltar'),
                                          onPressed: () {
                                            FocusScope.of(context)
                                                .requestFocus(myFocusNode);
                                            gravaEan(ctrlEan.text,
                                                widget.codigo, oldEan);
                                            gravaEstoque(
                                                '${ctrlEstoque.text.replaceAll(',', '.')}',
                                                widget.codigo,
                                                oldEstoque);
                                            gravaPreco(
                                                '${ctrlVenda.text.replaceAll(',', '.')}',
                                                widget.codigo,
                                                oldEstoque);
                                            Navigator.of(context).pop();
                                          }),
                                    ),
                                  )
                                ],
                              ),
                              onPressed: () {
                                FocusScope.of(context)
                                    .requestFocus(myFocusNode);
                                gravaEan(ctrlEan.text, widget.codigo, oldEan);
                                gravaEstoque(
                                    '${ctrlEstoque.text.replaceAll(',', '.')}',
                                    widget.codigo,
                                    oldEstoque);
                                gravaPreco(
                                    '${ctrlVenda.text.replaceAll(',', '.')}',
                                    widget.codigo,
                                    oldEstoque);
                                Navigator.of(context).pop();
                              },
                            ),
                            new Text(
                              '',
                              style: new TextStyle(
                                  fontSize: 16.0, fontWeight: FontWeight.bold),
                            ),
                            FlatButton(
                                shape: new RoundedRectangleBorder(
                                    borderRadius:
                                        new BorderRadius.circular(30.0)),
                                splashColor: Colors.deepPurple,
                                color: Colors.deepOrange,
                                child: new Row(
                                  children: <Widget>[
                                    new Padding(
                                      padding:
                                          const EdgeInsets.only(left: 20.0),
                                      child: Text(
                                        "ESCANEAR CÓDIGO",
                                        style: TextStyle(
                                            fontFamily: 'Quicksand',
                                            color: Colors.white),
                                      ),
                                    ),
                                    new Expanded(
                                      child: Container(),
                                    ),
                                    new Transform.translate(
                                      offset: Offset(15.0, 0.0),
                                      child: new Container(
                                        padding: const EdgeInsets.all(5.0),
                                        child: FlatButton(
                                          shape: new RoundedRectangleBorder(
                                              borderRadius:
                                                  new BorderRadius.circular(
                                                      28.0)),
                                          splashColor: Colors.blueGrey,
                                          color: Colors.white,
                                          child: Icon(
                                            Icons.camera_alt,
                                            color: Colors.deepOrange,
                                            size: 30,
                                          ),
                                          onPressed: () {
                                            scan();
                                          },
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                                onPressed: scan()),
                          ],
                        )
                      ],
                    ),
                  ))
                ],
              ),
            ),
          ),
        ),
      ]),
    );
  }

  void getControllers() async {
    sharedPreferences = await SharedPreferences.getInstance();
    setState(() {
      ctrlEan.text = widget.ean;
      ipserver = sharedPreferences.getString("ipserver");
      ctrlEstoque.text = widget.estoque;
      ctrlVenda.text = widget.valor;

      oldEan = widget.ean;
      oldEstoque = widget.estoque;
      oldValor = widget.valor;
    });
  }

  requestPermission() async {
    final result = await SimplePermissions.requestPermission(permission);
    setState(
      () => new SnackBar(
        backgroundColor: Colors.red,
        content: new Text(" $result"),
      ),
    );
  }

  scan() async {
    try {
      String reader = await scanner.scan();

      if (!mounted) {
        return;
      }

      setState(() {
        ctrlEan.text = reader;
      });
    } on PlatformException catch (e) {
      if (e.code == scanner.CameraAccessDenied) {
        requestPermission();
      }
    }
  }
}
