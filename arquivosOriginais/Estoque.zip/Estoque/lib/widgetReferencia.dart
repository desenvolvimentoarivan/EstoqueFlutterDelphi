import 'package:Estoque/dm/consultas.dart';
import 'package:Estoque/widgetListaReferencia.dart';
import 'package:http/http.dart' as http;
import 'UI/CustomInputField.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class WidgetReferencia extends StatefulWidget {
  @override
  _WidgetReferenciaState createState() => _WidgetReferenciaState();
}

class _WidgetReferenciaState extends State<WidgetReferencia> {
  TextEditingController referencia = TextEditingController();
  SharedPreferences sharedPreferences;
  String ip;

  @override
  void initState() {
    super.initState();
    _getIP();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: new GestureDetector(
        onTap: () {
          // call this method here to hide soft keyboard
          FocusScope.of(context).requestFocus(new FocusNode());
        },
        child: SingleChildScrollView(
          child: Container(
            decoration: new BoxDecoration(
              image: new DecorationImage(
                image: AssetImage('assets/background.png'),
                fit: BoxFit.cover,
              ),
            ),
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: Stack(
              children: <Widget>[
                Center(
                  child: Container(
                    //width: 500,
                    width: MediaQuery.of(context).size.width,
                    height: 500,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        Material(
                            elevation: 10.0,
                            borderRadius:
                                BorderRadius.all(Radius.circular(100.0)),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                'Digite a referência',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 25,
                                    color: Colors.deepOrange),
                              ),
                            )),
                        EditTexto(Icon(Icons.code, color: Colors.white),
                            'Mín. de 4 caracteres', referencia),
                        Container(
                          width: 250,
                          margin: const EdgeInsets.only(top: 10.0),
                          child: new Row(
                            children: <Widget>[
                              new Expanded(
                                child: FlatButton(
                                  shape: new RoundedRectangleBorder(
                                      borderRadius:
                                          new BorderRadius.circular(30.0)),
                                  splashColor: Colors.deepPurple,
                                  color: Colors.deepOrange,
                                  child: new Row(
                                    children: <Widget>[
                                      new Padding(
                                        padding:
                                            const EdgeInsets.only(left: 20.0),
                                        child: Text(
                                          "Pesquisar",
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      ),
                                      new Expanded(
                                        child: Container(),
                                      ),
                                      new Transform.translate(
                                        offset: Offset(15.0, 0.0),
                                        child: new Container(
                                          padding: const EdgeInsets.all(5.0),
                                          child: FlatButton(
                                            shape: new RoundedRectangleBorder(
                                                borderRadius:
                                                    new BorderRadius.circular(
                                                        28.0)),
                                            splashColor: Colors.blueGrey,
                                            color: Colors.white,
                                            child: Text('Voltar'),
                                            onPressed: () {
                                              Navigator.of(context).pop();
                                            },
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                  onPressed: () {
                                    _clicaPesquisa();
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  _getIP() async {
    sharedPreferences = await SharedPreferences.getInstance();
    ip = sharedPreferences.getString("ipserver");
  }

  _clicaPesquisa() {
    if (referencia.text.length >= 4) {
      fetchListProd();
    } else {
      alerta("Digite no mínimo 4 dígitos");
    }
  }

  fetchListProd() async {
    final response = await http.get('http://' +
        ip +
        ':8082/eventos/ProdRef?' +
        'pSelect=' +
        referencia.text);
    if (response.statusCode == 200) {
      if (response.body != '{"PRODUTOS": "VAZIO"}') {
        Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => WidgetListaReferencia(
                    text: referencia.text,
                  ),
            ));
      } else {
        alerta('Nenhum produto encontrado');
      }
    } else {
      alerta("Sem conexão com o servidor");
    }
  }
}