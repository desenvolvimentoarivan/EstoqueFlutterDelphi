import 'package:Estoque/configIP.dart';
import 'package:Estoque/dm/consultas.dart';
import 'UI/CustomInputField.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:Estoque/widgetmenu.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  TextEditingController userserver = TextEditingController();

  TextEditingController pwserver = TextEditingController();

  SharedPreferences sharedPreferences;

  bool apiCall = false;
  String servidor = '';
  bool usuario = false;

  String usuarioConectado = '';

  @override
  void initState() {
    super.initState();
    getCredential();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GestureDetector(
        onTap: () {
          // call this method here to hide soft keyboard
          FocusScope.of(context).requestFocus(new FocusNode());
        },
        child: SingleChildScrollView(
          child: Container(
            decoration: new BoxDecoration(
              image: new DecorationImage(
                image: AssetImage('assets/background.png'),
                fit: BoxFit.cover,
              ),
            ),

            width: MediaQuery.of(context).size.width,
            //width: 250,
            height: MediaQuery.of(context).size.height,
            //color: Colors.white,
            child: Stack(
              children: <Widget>[
                Center(
                  child: Container(
                    //width: 500,
                    width: MediaQuery.of(context).size.width,
                    height: 500,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        Material(
                            elevation: 10.0,
                            borderRadius:
                                BorderRadius.all(Radius.circular(100.0)),
                            child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: InkWell(
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      PageRouteBuilder(
                                          transitionDuration:
                                              Duration(milliseconds: 500),
                                          pageBuilder: (_, __, ___) =>
                                              ConfigIP()),
                                    );
                                  },
                                  child: Hero(
                                    tag: 'config',
                                    child: Image(
                                      image: AssetImage('assets/estoque.png'),
                                      width: 150,
                                      height: 150,
                                    ),
                                    transitionOnUserGestures: true,
                                  ),
                                ))),
                        EditTexto(Icon(Icons.person, color: Colors.white),
                            'Usuário', userserver),
                        EditSenha('Senha', pwserver),
                        Container(
                          width: 250,
                          margin: const EdgeInsets.only(top: 10.0),
                          child: new Row(
                            children: <Widget>[
                              new Expanded(
                                child: FlatButton(
                                  shape: new RoundedRectangleBorder(
                                      borderRadius:
                                          new BorderRadius.circular(30.0)),
                                  splashColor: Colors.deepPurple,
                                  color: Colors.deepOrange,
                                  child: new Row(
                                    children: <Widget>[
                                      new Padding(
                                        padding:
                                            const EdgeInsets.only(left: 20.0),
                                        child: Text(
                                          "LOGIN",
                                          style: TextStyle(
                                              fontFamily: 'Quicksand',
                                              color: Colors.white),
                                        ),
                                      ),
                                      new Expanded(
                                        child: Container(),
                                      ),
                                      new Transform.translate(
                                        offset: Offset(15.0, 0.0),
                                        child: new Container(
                                          padding: const EdgeInsets.all(5.0),
                                          child: FlatButton(
                                            shape: new RoundedRectangleBorder(
                                                borderRadius:
                                                    new BorderRadius.circular(
                                                        28.0)),
                                            splashColor: Colors.blueGrey,
                                            color: Colors.white,
                                            child: Icon(
                                              Icons.arrow_forward,
                                              color: Colors.deepOrange,
                                              size: 30,
                                            ),
                                            onPressed: () => _clicaLogin(),
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                  onPressed: () => _clicaLogin(),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  getCredential() async {
    sharedPreferences = await SharedPreferences.getInstance();
    setState(() {
      servidor = sharedPreferences.getString("ipserver");
      userserver.text = sharedPreferences.getString("userserver");
    });
  }

  void salvaTudo() async {
    apiCall = true;
    sharedPreferences = await SharedPreferences.getInstance();
    setState(() {
      // sharedPreferences.setString("ipserver", ipserver.text);
      sharedPreferences.setString("userserver", userserver.text);
      //sharedPreferences.commit();

      getCredential();
    });
    login(userserver.text);
  }

  _clicaLogin() {
    if (servidor == '') {
      getCredential();
    }
    if (servidor.length != 0 &&
        userserver.text.length != 0 &&
        pwserver.text.length != 0) {
      salvaTudo();
    } else {
      alerta("Preencha todos os campos");
    }
  }

  void login(String username) async {
    String url = 'http://' +
        servidor +
        ':8082/eventos/Login?pSelect=' +
        username +
        '&pSenha=' +
        pwserver.text;
    http.Response response;
    try {
     response = await http.post(url);
     apiCall = false;
     if (response.statusCode == 200) {
      if (response.body != '{"UCLOGIN": "ERRO"}') {
        Navigator.push(
            //é igual a form show
            context,
            MaterialPageRoute(
              builder: (context) => WidgetMenu(
                    ip: servidor,
                  ),
            ));
      } else {
        alerta('Usuário ou senha inválidos');
      }
    }
    } catch (error) {
      alerta('IP errado ou servidor off-line');
    }

    

  }

  getProperWidget() {
    if (apiCall) return new CircularProgressIndicator();
  }
}
