import 'package:Estoque/dm/consultas.dart';
import 'package:Estoque/widgetListaLike.dart';
import 'package:http/http.dart' as http;
import 'UI/CustomInputField.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class WIdGetCodProduto extends StatefulWidget {
  @override
  _WIdGetCodProdutoState createState() => _WIdGetCodProdutoState();
}

class _WIdGetCodProdutoState extends State<WIdGetCodProduto> {
  TextEditingController codProduto = TextEditingController();
  SharedPreferences sharedPreferences;
  String ip;

  @override
  void initState() {
    super.initState();
    _getIP();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: new GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(new FocusNode());
        },
        child: SingleChildScrollView(
          child: Container(
            decoration: new BoxDecoration(
              image: new DecorationImage(
                image: AssetImage('assets/background.png'),
                fit: BoxFit.cover,
              ),
            ),
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: Stack(
              children: <Widget>[
                Center(
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    height: 500,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        Material(
                            elevation: 10.0,
                            borderRadius:
                                BorderRadius.all(Radius.circular(100.0)),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                'Digite o código interno',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 25,
                                    color: Colors.deepOrange),
                              ),
                            )),
                        EditNumeroOnly(Icon(Icons.code, color: Colors.white),
                            'Mín. de 4 dígitos', codProduto),
                        Container(
                          width: 250,
                          margin: const EdgeInsets.only(top: 10.0),
                          child: new Row(
                            children: <Widget>[
                              new Expanded(
                                child: FlatButton(
                                  shape: new RoundedRectangleBorder(
                                      borderRadius:
                                          new BorderRadius.circular(30.0)),
                                  splashColor: Colors.deepPurple,
                                  color: Colors.deepOrange,
                                  child: new Row(
                                    children: <Widget>[
                                      new Padding(
                                        padding:
                                            const EdgeInsets.only(left: 20.0),
                                        child: Text(
                                          "Pesquisar",
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      ),
                                      new Expanded(
                                        child: Container(),
                                      ),
                                      new Transform.translate(
                                        offset: Offset(15.0, 0.0),
                                        child: new Container(
                                          padding: const EdgeInsets.all(5.0),
                                          child: FlatButton(
                                            shape: new RoundedRectangleBorder(
                                                borderRadius:
                                                    new BorderRadius.circular(
                                                        28.0)),
                                            splashColor: Colors.blueGrey,
                                            color: Colors.white,
                                            child: Text('Voltar'),
                                            onPressed: () {
                                              Navigator.of(context).pop();
                                            },
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                  onPressed: () {
                                    _clicaPesquisa();
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  _getIP() async {
    sharedPreferences = await SharedPreferences.getInstance();
    ip = sharedPreferences.getString("ipserver");
  }

  _clicaPesquisa() {
    if (codProduto.text.length >= 4) {
      buscaProduto();
    } else {
      alerta("Digite no mínimo 4 dígitos");
    }
  }

  buscaProduto() async {
    var response = await http.get('http://' +
        ip +
        ':8082/eventos/ProdLike?' +
        'pSelect=' +
        codProduto.text);

    if (response.statusCode == 200) {
      if (response.body != '{"PRODUTOS": "VAZIO"}') {
        Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => WidgetListaLike(
                    text: codProduto.text,
                  ),
            ));
      } else {
        alerta('Nenhum produto encontrado');
      }
    } else {
      alerta("Sem conexão com o servidor");
    }
  }
}
