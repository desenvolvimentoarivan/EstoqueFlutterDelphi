import 'UI/CustomInputField.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ConfigIP extends StatefulWidget {
  @override
  _ConfigIPState createState() => _ConfigIPState();
}

class _ConfigIPState extends State<ConfigIP> {
  TextEditingController ipserver = TextEditingController();

  SharedPreferences sharedPreferences;

  bool checkValue = false;
  bool apiCall = false;
  String oldip;

  @override
  void initState() {
    super.initState();
    getCredential();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: new GestureDetector(
        onTap: () {
          // call this method here to hide soft keyboard
          FocusScope.of(context).requestFocus(new FocusNode());
        },
        child: SingleChildScrollView(
          child: Container(
            decoration: new BoxDecoration(
              image: new DecorationImage(
                image: AssetImage('assets/background.png'),
                fit: BoxFit.cover,
              ),
            ),

            width: MediaQuery.of(context).size.width,
            //width: 250,
            height: MediaQuery.of(context).size.height,
            //color: Colors.white,
            child: Stack(
              children: <Widget>[
                Center(
                  child: Container(
                    //width: 500,
                    width: MediaQuery.of(context).size.width,
                    height: 500,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        Material(
                            elevation: 10.0,
                            borderRadius:
                                BorderRadius.all(Radius.circular(100.0)),
                            child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: InkWell(
                                  onTap: () {
                                    Navigator.of(context).pop();
                                  },
                                  child: Hero(
                                    tag: 'config',
                                    child: Image(
                                      image: AssetImage('assets/wifi.png'),
                                      width: 150,
                                      height: 150,
                                    ),
                                    transitionOnUserGestures: true,
                                  ),
                                ))),
                        EditNumero(Icon(Icons.http, color: Colors.white),
                            'IP do servidor', ipserver),
                        Container(
                          width: 250,
                          margin: const EdgeInsets.only(top: 10.0),
                          child: new Row(
                            children: <Widget>[
                              new Expanded(
                                child: FlatButton(
                                  shape: new RoundedRectangleBorder(
                                      borderRadius:
                                          new BorderRadius.circular(30.0)),
                                  splashColor: Colors.deepPurple,
                                  color: Colors.deepOrange,
                                  child: new Row(
                                    children: <Widget>[
                                      new Padding(
                                        padding:
                                            const EdgeInsets.only(left: 20.0),
                                        child: Text(
                                          "Salvar",
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      ),
                                      new Expanded(
                                        child: Container(),
                                      ),
                                      new Transform.translate(
                                        offset: Offset(15.0, 0.0),
                                        child: new Container(
                                          padding: const EdgeInsets.all(5.0),
                                          child: FlatButton(
                                            shape: new RoundedRectangleBorder(
                                                borderRadius:
                                                    new BorderRadius.circular(
                                                        28.0)),
                                            splashColor: Colors.blueGrey,
                                            color: Colors.white,
                                            child: Icon(
                                              Icons.arrow_forward,
                                              color: Colors.deepOrange,
                                              size: 30,
                                            ),
                                            onPressed: () => 
                                                  salvaTudo(),
                                                
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                  onPressed: () => salvaTudo(),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  getCredential() async {
    sharedPreferences = await SharedPreferences.getInstance();
    setState(() {
      ipserver.text = sharedPreferences.getString("ipserver");
      oldip = sharedPreferences.getString("ipserver");
    });
  }

  void salvaTudo() async {
    //so salva se o ip mudar
    if (oldip != ipserver.text) {
      apiCall = true;
      sharedPreferences = await SharedPreferences.getInstance();
      setState(() {
        sharedPreferences.setString("ipserver", ipserver.text);
      });
    }
    Navigator.of(context).pop();
  }

  getProperWidget() {
    if (apiCall) return CircularProgressIndicator();
  }
}
