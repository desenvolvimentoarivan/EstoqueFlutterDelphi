import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:Estoque/UI/splashscreen.dart';
import 'package:Estoque/myapp.dart';

void main() {
//  ConnectionStatusSingleton connectionStatus =
 //     ConnectionStatusSingleton.getInstance();
 // var initialize = connectionStatus.initialize();
  SystemChrome.setPreferredOrientations(
      [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]).then((_) {
    runApp(new MaterialApp(
      home: new MySplash(),
    ));
  });
}

class MySplash extends StatefulWidget {
  @override
  _MySplashState createState() => new _MySplashState();
}

class _MySplashState extends State<MySplash> {
  @override
  Widget build(BuildContext context) {
    
    return SplashScreen(
        seconds: 3,
        navigateAfterSeconds: new MyApp(),
        title: new Text(
          'Conferência de estoque',
          style: new TextStyle(fontWeight: FontWeight.bold, fontSize: 20.0),
        ),
        image: Image.asset('assets/estoque.png'),
        backgroundColor: Colors.white,
        styleTextUnderTheLoader: new TextStyle(),
        photoSize: 200.0,
        onClick: () {},
        loaderColor: Colors.red);
  }
}
